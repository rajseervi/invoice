// ... existing code ...

// Update the navigation items to ensure consistent paths
const navItems = [
  { text: 'Dashboard', icon: <DashboardIcon />, path: '/' },
  { text: 'Invoices', icon: <ReceiptLongIcon />, path: '/invoices' },
  { text: 'Products', icon: <InventoryIcon />, path: '/products' },
  { text: 'Categories', icon: <CategoryIcon />, path: '/products/categories' },
  { text: 'Parties', icon: <PeopleIcon />, path: '/parties' },
  { text: 'Reports', icon: <AssessmentIcon />, path: '/reports' },
  { text: 'Settings', icon: <SettingsIcon />, path: '/settings' },
];

// ... existing code ...