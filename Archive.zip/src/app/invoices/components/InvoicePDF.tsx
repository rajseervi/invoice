"use client";
import React from 'react';
import { Button, Box, Tooltip } from '@mui/material';
import { Download as DownloadIcon, Print as PrintIcon } from '@mui/icons-material';
import jsPDF from 'jspdf';
// Import the autotable plugin correctly
import autoTable from 'jspdf-autotable';

interface InvoicePDFProps {
  invoice: {
    invoiceNumber: string;
    date: string;
    partyName: string;
    partyAddress?: string;
    partyEmail?: string;
    partyPhone?: string;
    items: any[];
    subtotal: number;
    discount: number;
    total: number;
  };
}

const InvoicePDF: React.FC<InvoicePDFProps> = ({ invoice }) => {
  const generatePDF = () => {
    // Create a new jsPDF instance
    const doc = new jsPDF();
    
    // Add logo/header
    doc.setFillColor(41, 98, 255);
    doc.rect(0, 0, doc.internal.pageSize.width, 25, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(22);
    doc.text('INVOICE', 20, 15);
    doc.setTextColor(0, 0, 0);
    
    // Add invoice details
    doc.setFontSize(10);
    doc.text(`Invoice Number: ${invoice.invoiceNumber}`, 150, 40, { align: 'right' });
    doc.text(`Date: ${invoice.date}`, 150, 45, { align: 'right' });
    
    // Add customer info
    doc.setFontSize(12);
    doc.text('Bill To:', 20, 40);
    doc.setFontSize(10);
    doc.text(invoice.partyName, 20, 45);
    if (invoice.partyAddress) {
      doc.text(invoice.partyAddress, 20, 50);
    }
    if (invoice.partyEmail) {
      doc.text(`Email: ${invoice.partyEmail}`, 20, 55);
    }
    if (invoice.partyPhone) {
      doc.text(`Phone: ${invoice.partyPhone}`, 20, 60);
    }
    
    // Add table
    const tableColumn = ["Product", "Price", "Quantity", "Discount", "Total"];
    const tableRows = invoice.items.map(item => [
      item.name,
      `₹${item.price.toFixed(2)}`,
      item.quantity.toString(),
      item.discount > 0 ? `${item.discount}%` : '-',
      `₹${item.finalPrice.toFixed(2)}`
    ]);
    
    // Use autoTable correctly
    autoTable(doc, {
      head: [tableColumn],
      body: tableRows,
      startY: 70,
      theme: 'grid',
      styles: { fontSize: 8 },
      headStyles: { fillColor: [41, 98, 255], textColor: [255, 255, 255] },
      alternateRowStyles: { fillColor: [240, 240, 240] },
      margin: { left: 20, right: 20 }
    });
    
    // Get the last page's Y position
    const finalY = (doc as any).lastAutoTable.finalY || 120;
    
    // Add summary with better styling
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.line(110, finalY + 5, 190, finalY + 5);
    
    doc.text('Subtotal:', 130, finalY + 10);
    doc.text(`₹${invoice.subtotal.toFixed(2)}`, 170, finalY + 10, { align: 'right' });
    
    doc.text('Discount:', 130, finalY + 15);
    doc.text(`₹${invoice.discount.toFixed(2)}`, 170, finalY + 15, { align: 'right' });
    
    doc.setFillColor(240, 240, 240);
    doc.rect(110, finalY + 20, 80, 10, 'F');
    doc.setFontSize(12);
    doc.setFont(undefined, 'bold');
    doc.text('Total:', 130, finalY + 27);
    doc.text(`₹${invoice.total.toFixed(2)}`, 170, finalY + 27, { align: 'right' });
    doc.setFont(undefined, 'normal');
    
    // Add footer
    doc.setFillColor(41, 98, 255);
    doc.rect(0, doc.internal.pageSize.height - 20, doc.internal.pageSize.width, 20, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8);
    doc.text('Thank you for your business!', 105, doc.internal.pageSize.height - 10, { align: 'center' });
    
    // Save the PDF
    doc.save(`Invoice-${invoice.invoiceNumber}.pdf`);
  };

  const printPDF = () => {
    const pdf = generatePDF();
    // This would typically open the PDF in a new window for printing
    // For now, we'll just call the generate function
  };

  return (
    <Box sx={{ mt: 2, display: 'flex', gap: 2 }}>
      <Tooltip title="Download as PDF">
        <Button
          variant="contained"
          color="primary"
          startIcon={<DownloadIcon />}
          onClick={generatePDF}
        >
          Download PDF
        </Button>
      </Tooltip>
      
      <Tooltip title="Print invoice">
        <Button
          variant="outlined"
          color="primary"
          startIcon={<PrintIcon />}
          onClick={printPDF}
        >
          Print
        </Button>
      </Tooltip>
    </Box>
  );
};

export default InvoicePDF;