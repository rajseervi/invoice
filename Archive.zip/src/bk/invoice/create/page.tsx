"use client"
import React, { useState } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  TextField,
  Button,
  Grid,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Autocomplete,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
} from '@mui/material';
import { Delete, Add } from '@mui/icons-material';
import DashboardLayout from '../../../components/DashboardLayout/DashboardLayout';
import { PDFDocument, rgb } from '@react-pdf/renderer';
import { useRouter } from 'next/navigation';
import { DatePicker } from '@mui/x-date-pickers';
import dayjs from 'dayjs';
import Link from 'next/link';

interface Product {
  id: string;
  name: string;
  price: number;
  description?: string;
 number;
  price: number;
  total: number;
}

const dummyProducts: Product[] = [
  { id: '1', name: 'Product A', price: 100 },
  { id: '2', name: 'Product B', price: 200 },
];

interface InvoiceDetails {
  invoiceNumber: string;
  date: Date;
  dueDate: Date;
  terms?: string;
  notes?: string;
}

export default function CreateInvoice() {
  const router = useRouter();
  const [items, setItems] = useState<InvoiceItem[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({});
  const [customer, setCustomer] = useState({
    name: '',
    email: '',
    address: '',
  });

  const handleAddItem = (product: Product) => {
    setItems([
      ...items,
      {
        product,
        quantity: 1,
        price: product.price,
        total: product.price,
      },
    ]);
  };

  const handleQuantityChange = (index: number, quantity: number) => {
    const newItems = [...items];
    newItems[index].quantity = quantity;
    newItems[index].total = quantity * newItems[index].price;
    setItems(newItems);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const handleCreateProduct = () => {
    const product = {
      ...newProduct,
      id: Date.now().toString(),
    } as Product;
    dummyProducts.push(product);
    setNewProduct({});
    setOpenDialog(false);
  };

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + item.total, 0);
  };

  const validateForm = () => {
    if (!customer.name || !customer.email || !customer.address) {
      return 'Please fill in all customer details';
    }
    if (items.length === 0) {
      return 'Please add at least one item';
    }
    if (items.some(item => item.quantity <= 0)) {
      return 'Quantity must be greater than 0';
    }
    return null;
  };

  const handleSaveDraft = async () => {
    // Save to local storage or database
    const draft = {
      customer,
      items,
      invoiceDetails,
      status: 'draft',
      lastModified: new Date()
    };
    localStorage.setItem(`invoice-draft-${invoiceDetails.invoiceNumber}`, JSON.stringify(draft));
    router.push('/invoice');
  };

  const handleGenerateInvoice = async () => {
    const error = validateForm();
    if (error) {
      // Show error message
      return;
    }

    const invoice = {
      customer,
      items,
      invoiceDetails,
      status: 'pending',
      total: calculateTotal(),
      createdAt: new Date()
    };

    // Save invoice and generate PDF
    try {
      // Save to database logic here
      await generatePDF(invoice);
      router.push('/invoice');
    } catch (error) {
      console.error('Failed to generate invoice:', error);
    }
  };

  return (
    <DashboardLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h5">Create New Invoice</Typography>
          <Link href="/invoice">
            <Button variant="outlined">View All Invoices</Button>
          </Link>
        </Box>

        <Paper sx={{ p: 4 }}>
          <Typography variant="h5" gutterBottom>
            Create New Invoice
          </Typography>

          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Customer Name"
                value={customer.name}
                onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Customer Email"
                value={customer.email}
                onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
              />
            </Grid>
            <Grid item xs={12} md={4}>
              <TextField
                fullWidth
                label="Customer Address"
                value={customer.address}
                onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
              />
            </Grid>
          </Grid>

          <Box sx={{ mb: 3, display: 'flex', gap: 2 }}>
            <Autocomplete
              options={dummyProducts}
              getOptionLabel={(option) => option.name}
              sx={{ width: 300 }}
              renderInput={(params) => <TextField {...params} label="Add Product" />}
              onChange={(_, value) => value && handleAddItem(value)}
            />
            <Button
              variant="outlined"
              startIcon={<Add />}
              onClick={() => setOpenDialog(true)}
            >
              New Product
            </Button>
          </Box>

          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Product</TableCell>
                  <TableCell align="right">Price</TableCell>
                  <TableCell align="right">Quantity</TableCell>
                  <TableCell align="right">Total</TableCell>
                  <TableCell align="center">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {items.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.product.name}</TableCell>
                    <TableCell align="right">₹{item.price}</TableCell>
                    <TableCell align="right">
                      <TextField
                        type="number"
                        value={item.quantity}
                        onChange={(e) => handleQuantityChange(index, Number(e.target.value))}
                        size="small"
                        sx={{ width: 80 }}
                      />
                    </TableCell>
                    <TableCell align="right">₹{item.total}</TableCell>
                    <TableCell align="center">
                      <IconButton onClick={() => handleRemoveItem(index)} color="error">
                        <Delete />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow>
                  <TableCell colSpan={3} align="right">
                    <Typography variant="subtitle1" fontWeight="bold">
                      Total:
                    </Typography>
                  </TableCell>
                  <TableCell align="right">
                    <Typography variant="subtitle1" fontWeight="bold">
                      ₹{calculateTotal()}
                    </Typography>
                  </TableCell>
                  <TableCell />
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>

          <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
            <Button variant="outlined" onClick={handleSaveDraft}>Save as Draft</Button>
            <Button variant="contained" onClick={handleGenerateInvoice}>Generate Invoice</Button>
          </Box>
        </Paper>

        <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
          <DialogTitle>Add New Product</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Product Name"
              fullWidth
              value={newProduct.name || ''}
              onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
            />
            <TextField
              margin="dense"
              label="Price"
              type="number"
              fullWidth
              value={newProduct.price || ''}
              onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })}
            />
            <TextField
              margin="dense"
              label="Description"
              fullWidth
              multiline
              rows={3}
              value={newProduct.description || ''}
              onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setOpenDialog(false)}>Cancel</Button>
            <Button onClick={handleCreateProduct} variant="contained">
              Create
            </Button>
          </DialogActions>
        </Dialog>
      </Container>
    </DashboardLayout>
  );
}