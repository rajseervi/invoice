"use client"
import React, { useState } from 'react';
import Link from 'next/link';
// ... other imports ...

export default function InvoiceList() {
  // ... existing state and handlers ...

  return (
    <DashboardLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
          <Typography variant="h5">Invoices</Typography>
          <Link href="/invoice/create">
            <Button variant="contained" startIcon={<Add />}>
              Create Invoice
            </Button>
          </Link>
        </Box>

        {/* ... rest of the invoice list content ... */}

        <TableBody>
          {filteredInvoices.map((invoice) => (
            <TableRow key={invoice.id}>
              <TableCell>
                <Link href={`/invoice/${invoice.id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
                  {invoice.id}
                </Link>
              </TableCell>
              {/* ... other table cells ... */}
            </TableRow>
          ))}
        </TableBody>
      </Container>
    </DashboardLayout>
  );
}