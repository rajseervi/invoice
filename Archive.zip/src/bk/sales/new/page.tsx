// "use client"
// import React, { useState, useEffect } from 'react';
// import Layout from '@/app/components/Layout/Layout';
// import {
//   Container,
//   Typography,
//   Paper,
//   Box,
//   TextField,
//   Button,
//   Grid,
//   Autocomplete,
//   Table,
//   TableBody,
//   TableCell,
//   TableContainer,
//   TableHead,
//   TableRow,
//   IconButton,
//   Divider,
//   FormControl,
//   InputLabel,
//   Select,
//   MenuItem,
//   InputAdornment,
//   CircularProgress,
//   Alert,
//   Card,Chip,
//   CardContent
// } from '@mui/material';
// import {
//   Delete as DeleteIcon,
//   Add as AddIcon,
//   Print as PrintIcon,
//   Save as SaveIcon
// } from '@mui/icons-material';
// import { 
//   collection, 
//   getDocs, 
//   addDoc, 
//   doc, 
//   getDoc 
// } from 'firebase/firestore';
// import { db } from '@/firebase/config';

// // Define interfaces
// interface Product {
//   id: string;
//   name: string;
//   category: string;
//   price: number;
//   stock: number;
// }

// interface Category {
//   id: string;
//   name: string;
//   discount?: number;
// }

// interface Party {
//   id: string;
//   name: string;
//   email: string;
//   phone: string;
//   address: string;
//   categoryDiscounts: Record<string, number>;
// }

// interface InvoiceItem {
//   product: Product;
//   quantity: number;
//   price: number;
//   discount: number;
//   total: number;
// }

// export default function NewInvoicePage() {
//   // State for products, categories, and parties
//   const [products, setProducts] = useState<Product[]>([]);
//   const [categories, setCategories] = useState<Category[]>([]);
//   const [parties, setParties] = useState<Party[]>([]);
  
//   // State for selected party and invoice items
//   const [selectedParty, setSelectedParty] = useState<Party | null>(null);
//   const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
//   const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
//   const [quantity, setQuantity] = useState<number>(1);
  
//   // State for invoice details
//   const [invoiceNumber, setInvoiceNumber] = useState<string>('');
//   const [invoiceDate, setInvoiceDate] = useState<string>(new Date().toISOString().split('T')[0]);
//   const [notes, setNotes] = useState<string>('');
  
//   // Loading and error states
//   const [loading, setLoading] = useState<boolean>(true);
//   const [error, setError] = useState<string | null>(null);

//   // Fetch data from Firebase
//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         setLoading(true);
        
//         // Fetch products
//         const productsCollection = collection(db, 'products');
//         const productsSnapshot = await getDocs(productsCollection);
//         const productsList = productsSnapshot.docs.map(doc => ({
//           id: doc.id,
//           ...doc.data()
//         } as Product));
//         setProducts(productsList);
        
//         // Fetch categories
//         const categoriesCollection = collection(db, 'categories');
//         const categoriesSnapshot = await getDocs(categoriesCollection);
//         const categoriesList = categoriesSnapshot.docs.map(doc => ({
//           id: doc.id,
//           ...doc.data()
//         } as Category));
//         setCategories(categoriesList);
        
//         // Fetch parties
//         const partiesCollection = collection(db, 'parties');
//         const partiesSnapshot = await getDocs(partiesCollection);
//         const partiesList = partiesSnapshot.docs.map(doc => ({
//           id: doc.id,
//           ...doc.data(),
//           categoryDiscounts: doc.data().categoryDiscounts || {}
//         } as Party));
//         setParties(partiesList);
        
//         // Generate invoice number
//         setInvoiceNumber(`INV-${Date.now().toString().slice(-6)}`);
        
//         setError(null);
//       } catch (err) {
//         console.error('Error fetching data:', err);
//         setError('Failed to fetch data. Please try again later.');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchData();
//   }, []);

//   // Handle party selection
//   const handlePartyChange = (event: any, newValue: Party | null) => {
//     setSelectedParty(newValue);
//   };

//   // Handle product selection
//   const handleProductChange = (event: any, newValue: Product | null) => {
//     setSelectedProduct(newValue);
//     setQuantity(1);
//   };

//   // Add product to invoice
//   const handleAddProduct = () => {
//     if (!selectedProduct || quantity <= 0) return;
    
//     // Check if product already exists in invoice
//     const existingItemIndex = invoiceItems.findIndex(item => item.product.id === selectedProduct.id);
    
//     if (existingItemIndex !== -1) {
//       // Update existing item
//       const updatedItems = [...invoiceItems];
//       const item = updatedItems[existingItemIndex];
//       const newQuantity = item.quantity + quantity;
      
//       // Calculate discount based on category
//       const discount = selectedParty?.categoryDiscounts?.[selectedProduct.category] || 0;
      
//       updatedItems[existingItemIndex] = {
//         ...item,
//         quantity: newQuantity,
//         discount: discount,
//         total: calculateItemTotal(selectedProduct.price, newQuantity, discount)
//       };
      
//       setInvoiceItems(updatedItems);
//     } else {
//       // Add new item
//       // Calculate discount based on category
//       const discount = selectedParty?.categoryDiscounts?.[selectedProduct.category] || 0;
      
//       const newItem: InvoiceItem = {
//         product: selectedProduct,
//         quantity: quantity,
//         price: selectedProduct.price,
//         discount: discount,
//         total: calculateItemTotal(selectedProduct.price, quantity, discount)
//       };
      
//       setInvoiceItems([...invoiceItems, newItem]);
//     }
    
//     // Reset selection
//     setSelectedProduct(null);
//     setQuantity(1);
//   };

//   // Calculate item total with discount
//   const calculateItemTotal = (price: number, qty: number, discount: number) => {
//     return price * qty * (1 - discount / 100);
//   };

//   // Remove item from invoice
//   const handleRemoveItem = (index: number) => {
//     const updatedItems = [...invoiceItems];
//     updatedItems.splice(index, 1);
//     setInvoiceItems(updatedItems);
//   };

//   // Calculate subtotal
//   const calculateSubtotal = () => {
//     return invoiceItems.reduce((sum, item) => sum + item.total, 0);
//   };

//   // Calculate total discount amount
//   const calculateTotalDiscount = () => {
//     return invoiceItems.reduce((sum, item) => {
//       const itemTotal = item.price * item.quantity;
//       const discountAmount = itemTotal * (item.discount / 100);
//       return sum + discountAmount;
//     }, 0);
//   };

//   // Calculate tax (assuming 18% GST)
//   const calculateTax = () => {
//     return calculateSubtotal() * 0.18;
//   };

//   // Calculate grand total
//   const calculateGrandTotal = () => {
//     return calculateSubtotal() + calculateTax();
//   };

//   // Save invoice to Firebase
//   const handleSaveInvoice = async () => {
//     if (!selectedParty || invoiceItems.length === 0) {
//       setError('Please select a party and add at least one product.');
//       return;
//     }
    
//     try {
//       setLoading(true);
      
//       const invoiceData = {
//         invoiceNumber,
//         invoiceDate,
//         party: {
//           id: selectedParty.id,
//           name: selectedParty.name,
//           email: selectedParty.email,
//           phone: selectedParty.phone,
//           address: selectedParty.address
//         },
//         items: invoiceItems.map(item => ({
//           productId: item.product.id,
//           productName: item.product.name,
//           category: item.product.category,
//           quantity: item.quantity,
//           price: item.price,
//           discount: item.discount,
//           total: item.total
//         })),
//         subtotal: calculateSubtotal(),
//         discount: calculateTotalDiscount(),
//         tax: calculateTax(),
//         total: calculateGrandTotal(),
//         notes,
//         createdAt: new Date()
//       };
      
//       const invoicesCollection = collection(db, 'invoices');
//       await addDoc(invoicesCollection, invoiceData);
      
//       // Reset form
//       setSelectedParty(null);
//       setInvoiceItems([]);
//       setNotes('');
//       setInvoiceNumber(`INV-${Date.now().toString().slice(-6)}`);
//       setInvoiceDate(new Date().toISOString().split('T')[0]);
      
//       alert('Invoice saved successfully!');
//       setError(null);
//     } catch (err) {
//       console.error('Error saving invoice:', err);
//       setError('Failed to save invoice. Please try again.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <Layout>
//       <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
//         <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
//           <Typography variant="h5">New Invoice</Typography>
//           <Box>
//             <Button 
//               variant="contained" 
//               startIcon={<SaveIcon />} 
//               onClick={handleSaveInvoice}
//               disabled={loading || !selectedParty || invoiceItems.length === 0}
//               sx={{ mr: 2 }}
//             >
//               Save Invoice
//             </Button>
//             <Button 
//               variant="outlined" 
//               startIcon={<PrintIcon />}
//               disabled={!selectedParty || invoiceItems.length === 0}
//             >
//               Print
//             </Button>
//           </Box>
//         </Box>

//         {error && (
//           <Alert severity="error" sx={{ mb: 3 }}>
//             {error}
//           </Alert>
//         )}

//         <Grid container spacing={3}>
//           {/* Invoice Details */}
//           <Grid item xs={12}>
//             <Paper sx={{ p: 3, mb: 3 }}>
//               <Grid container spacing={2}>
//                 <Grid item xs={12} md={4}>
//                   <TextField
//                     label="Invoice Number"
//                     fullWidth
//                     value={invoiceNumber}
//                     onChange={(e) => setInvoiceNumber(e.target.value)}
//                   />
//                 </Grid>
//                 <Grid item xs={12} md={4}>
//                   <TextField
//                     label="Invoice Date"
//                     type="date"
//                     fullWidth
//                     value={invoiceDate}
//                     onChange={(e) => setInvoiceDate(e.target.value)}
//                     InputLabelProps={{ shrink: true }}
//                   />
//                 </Grid>
//                 <Grid item xs={12} md={4}>
//                   <Autocomplete
//                     options={parties}
//                     getOptionLabel={(option) => option.name}
//                     value={selectedParty}
//                     onChange={handlePartyChange}
//                     renderInput={(params) => (
//                       <TextField {...params} label="Select Party" fullWidth />
//                     )}
//                   />
//                 </Grid>
//               </Grid>
              
//               {selectedParty && (
//                 <Box sx={{ mt: 2 }}>
//                   <Typography variant="subtitle2">Party Details:</Typography>
//                   <Typography variant="body2">
//                     {selectedParty.address}<br />
//                     Phone: {selectedParty.phone}<br />
//                     Email: {selectedParty.email}
//                   </Typography>
                  
//                   {Object.keys(selectedParty.categoryDiscounts || {}).length > 0 && (
//                     <Box sx={{ mt: 1 }}>
//                       <Typography variant="subtitle2">Category Discounts:</Typography>
//                       <Grid container spacing={1}>
//                         {Object.entries(selectedParty.categoryDiscounts).map(([category, discount]) => (
//                           <Grid item key={category}>
//                             <Chip 
//                               label={`${category}: ${discount}%`} 
//                               size="small" 
//                               color="primary" 
//                               variant="outlined"
//                             />
//                           </Grid>
//                         ))}
//                       </Grid>
//                     </Box>
//                   )}
//                 </Box>
//               )}
//             </Paper>
//           </Grid>

//           {/* Add Products */}
//           <Grid item xs={12}>
//             <Paper sx={{ p: 3, mb: 3 }}>
//               <Typography variant="h6" gutterBottom>
//                 Add Products
//               </Typography>
//               <Grid container spacing={2} alignItems="center">
//                 <Grid item xs={12} md={5}>
//                   <Autocomplete
//                     options={products}
//                     getOptionLabel={(option) => `${option.name} (${option.category})`}
//                     value={selectedProduct}
//                     onChange={handleProductChange}
//                     renderInput={(params) => (
//                       <TextField {...params} label="Select Product" fullWidth />
//                     )}
//                   />
//                 </Grid>
//                 <Grid item xs={12} md={2}>
//                   <TextField
//                     label="Quantity"
//                     type="number"
//                     fullWidth
//                     value={quantity}
//                     onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
//                     InputProps={{ inputProps: { min: 1 } }}
//                   />
//                 </Grid>
//                 <Grid item xs={12} md={3}>
//                   <TextField
//                     label="Price"
//                     fullWidth
//                     value={selectedProduct?.price || ''}
//                     InputProps={{
//                       readOnly: true,
//                       startAdornment: <InputAdornment position="start">₹</InputAdornment>,
//                     }}
//                   />
//                 </Grid>
//                 <Grid item xs={12} md={2}>
//                   <Button
//                     variant="contained"
//                     startIcon={<AddIcon />}
//                     onClick={handleAddProduct}
//                     disabled={!selectedProduct}
//                     fullWidth
//                   >
//                     Add
//                   </Button>
//                 </Grid>
//               </Grid>
//             </Paper>
//           </Grid>

//           {/* Invoice Items */}
//           <Grid item xs={12}>
//             <Paper sx={{ p: 3, mb: 3 }}>
//               <Typography variant="h6" gutterBottom>
//                 Invoice Items
//               </Typography>
//               <TableContainer>
//                 <Table>
//                   <TableHead>
//                     <TableRow>
//                       <TableCell>Product</TableCell>
//                       <TableCell>Category</TableCell>
//                       <TableCell align="right">Price</TableCell>
//                       <TableCell align="right">Quantity</TableCell>
//                       <TableCell align="right">Discount</TableCell>
//                       <TableCell align="right">Total</TableCell>
//                       <TableCell align="center">Action</TableCell>
//                     </TableRow>
//                   </TableHead>
//                   <TableBody>
//                     {invoiceItems.length === 0 ? (
//                       <TableRow>
//                         <TableCell colSpan={7} align="center">
//                           No items added to invoice
//                         </TableCell>
//                       </TableRow>
//                     ) : (
//                       invoiceItems.map((item, index) => (
//                         <TableRow key={index}>
//                           <TableCell>{item.product.name}</TableCell>
//                           <TableCell>{item.product.category}</TableCell>
//                           <TableCell align="right">₹{item.price.toFixed(2)}</TableCell>
//                           <TableCell align="right">{item.quantity}</TableCell>
//                           <TableCell align="right">{item.discount}%</TableCell>
//                           <TableCell align="right">₹{item.total.toFixed(2)}</TableCell>
//                           <TableCell align="center">
//                             <IconButton 
//                               size="small" 
//                               color="error"
//                               onClick={() => handleRemoveItem(index)}
//                             >
//                               <DeleteIcon />
//                             </IconButton>
//                           </TableCell>
//                         </TableRow>
//                       ))
//                     )}
//                   </TableBody>
//                 </Table>
//               </TableContainer>
//             </Paper>
//           </Grid>

//           {/* Invoice Summary */}
//           <Grid item xs={12} md={6}>
//             <Paper sx={{ p: 3 }}>
//               <Typography variant="h6" gutterBottom>
//                 Notes
//               </Typography>
//               <TextField
//                 multiline
//                 rows={4}
//                 fullWidth
//                 placeholder="Add notes to invoice..."
//                 value={notes}
//                 onChange={(e) => setNotes(e.target.value)}
//               />
//             </Paper>
//           </Grid>

//           <Grid item xs={12} md={6}>
//             <Paper sx={{ p: 3 }}>
//               <Typography variant="h6" gutterBottom>
//                 Summary
//               </Typography>
//               <Box sx={{ mt: 2 }}>
//                 <Grid container spacing={1}>
//                   <Grid item xs={6}>
//                     <Typography variant="body1">Subtotal:</Typography>
//                   </Grid>
//                   <Grid item xs={6}>
//                     <Typography variant="body1" align="right">
//                       ₹{calculateSubtotal().toFixed(2)}
//                     </Typography>
//                   </Grid>
                  
//                   <Grid item xs={6}>
//                     <Typography variant="body1">Discount:</Typography>
//                   </Grid>
//                   <Grid item xs={6}>
//                     <Typography variant="body1" align="right">
//                       ₹{calculateTotalDiscount().toFixed(2)}
//                     </Typography>
//                   </Grid>
                  
//                   <Grid item xs={6}>
//                     <Typography variant="body1">Tax (18%):</Typography>
//                   </Grid>
//                   <Grid item xs={6}>
//                     <Typography variant="body1" align="right">
//                       ₹{calculateTax().toFixed(2)}
//                     </Typography>
//                   </Grid>
                  
//                   <Grid item xs={12}>
//                     <Divider sx={{ my: 1 }} />
//                   </Grid>
                  
//                   <Grid item xs={6}>
//                     <Typography variant="h6">Total:</Typography>
//                   </Grid>
//                   <Grid item xs={6}>
//                     <Typography variant="h6" align="right">
//                       ₹{calculateGrandTotal().toFixed(2)}
//                     </Typography>
//                   </Grid>
//                 </Grid>
//               </Box>
//             </Paper>
//           </Grid>
//         </Grid>
//       </Container>
//     </Layout>
//   );
// }







"use client";
import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  TextField, 
  Button, 
  Table, 
  TableBody, 
  TableCell, 
  TableContainer, 
  TableHead, 
  TableRow, 
  Paper, 
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert
} from '@mui/material';
import { Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '@/firebase/config';
import Layout from '@/app/components/Layout/Layout';
// Custom hook to fetch and manage parties data
const useParties = () => {
  const [parties, setParties] = useState<Party[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchParties = async () => {
      try {
        const partiesCollection = collection(db, 'parties');
        const partiesSnapshot = await getDocs(partiesCollection);
        const partiesList = partiesSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          categoryDiscounts: doc.data().categoryDiscounts || {},
          productDiscounts: doc.data().productDiscounts || {}
        })) as Party[];
        setParties(partiesList);
        setError(null);
      } catch (err) {
        console.error('Error fetching parties:', err);
        setError('Failed to fetch parties');
      } finally {
        setLoading(false);
      }
    };

    fetchParties();
  }, []);

  return { parties, loading, error };
};

export { useParties };
import { useProducts, Product } from '@/app/hooks/useProducts';
import { 
  Dialog, 
  DialogTitle, 
  DialogContent, 
  DialogActions 
} from '@mui/material'; 

interface Party {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  categoryDiscounts: Record<string, number>;
  productDiscounts?: Record<string, number>;
}

interface InvoiceLineItem {
  productId: string;
  name: string;
  quantity: number;
  price: number;
  category: string;
  discount: number;
  discountType: 'none' | 'category' | 'product';
  finalPrice: number;
}

interface InvoiceFormProps {
  onSuccess?: () => void;
}

export default function NewInvoicePage({ onSuccess }: InvoiceFormProps) {
  const { parties, loading: loadingParties } = useParties();
  const { products, loading: loadingProducts } = useProducts();
  
  const [selectedPartyId, setSelectedPartyId] = useState<string>('');
  const [invoiceDate, setInvoiceDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [invoiceNumber, setInvoiceNumber] = useState<string>('');
  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Generate invoice number on component mount
  useEffect(() => {
    const generateInvoiceNumber = () => {
      const date = new Date();
      const year = date.getFullYear().toString().slice(-2);
      const month = (date.getMonth() + 1).toString().padStart(2, '0');
      const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      return `INV-${year}${month}-${random}`;
    };
    
    setInvoiceNumber(generateInvoiceNumber());
  }, []);
  
  // Get selected party
  const selectedParty = parties.find(party => party.id === selectedPartyId) || null;
  
  // Calculate discounts when party or line items change
  useEffect(() => {
    if (!selectedParty || lineItems.length === 0) return;
    
    const updatedItems = lineItems.map(item => {
      const product = products.find(p => p.id === item.productId);
      if (!product) return item;
      
      const categoryDiscount = selectedParty.categoryDiscounts[product.category] || 0;
      const productDiscount = selectedParty.productDiscounts?.[item.productId] || 0;
      
      // Use product-specific discount if available, otherwise category discount
      let discount = 0;
      let discountType: 'none' | 'category' | 'product' = 'none';
      
      if (productDiscount > 0) {
        discount = productDiscount;
        discountType = 'product';
      } else if (categoryDiscount > 0) {
        discount = categoryDiscount;
        discountType = 'category';
      }
      
      const finalPrice = item.price * (1 - discount/100) * item.quantity;
      
      return { 
        ...item, 
        discount, 
        discountType,
        finalPrice: parseFloat(finalPrice.toFixed(2))
      };
    });
    
    setLineItems(updatedItems);
  }, [selectedPartyId, products, selectedParty]);
  
  // Add product to invoice
  const handleAddProduct = () => {
    if (!selectedProductId) return;
    
    const product = products.find(p => p.id === selectedProductId);
    if (!product) return;
    
    const newItem: InvoiceLineItem = {
      productId: product.id,
      name: product.name,
      quantity: 1,
      price: product.price,
      category: product.category || '',
      discount: 0,
      discountType: 'none',
      finalPrice: product.price
    };
    
    setLineItems([...lineItems, newItem]);
    setSelectedProductId('');
  };
  
  // Update quantity
  const handleUpdateQuantity = (index: number, quantity: number) => {
    if (quantity < 1) return;
    
    const updatedItems = [...lineItems];
    updatedItems[index].quantity = quantity;
    
    // Recalculate final price
    const item = updatedItems[index];
    item.finalPrice = item.price * (1 - item.discount/100) * quantity;
    item.finalPrice = parseFloat(item.finalPrice.toFixed(2));
    
    setLineItems(updatedItems);
  };
  
  // Remove line item
  const handleRemoveItem = (index: number) => {
    setLineItems(lineItems.filter((_, i) => i !== index));
  };
  
  // Calculate totals
  const subtotal = lineItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const discountAmount = subtotal - lineItems.reduce((sum, item) => sum + item.finalPrice, 0);
  const total = subtotal - discountAmount;
  
  // Save invoice
  const handleSaveInvoice = async () => {
    if (!selectedPartyId || lineItems.length === 0) {
      setError('Please select a party and add at least one product');
      return;
    }
    
    try {
      setLoading(true);
      
      const invoiceData = {
        invoiceNumber,
        date: invoiceDate,
        partyId: selectedPartyId,
        partyName: selectedParty?.name || '',
        items: lineItems.map(item => ({
          productId: item.productId,
          name: item.name,
          quantity: item.quantity,
          price: item.price,
          discount: item.discount,
          discountType: item.discountType,
          finalPrice: item.finalPrice
        })),
        subtotal,
        discount: discountAmount,
        total,
        createdAt: serverTimestamp()
      };
      
      await addDoc(collection(db, 'invoices'), invoiceData);
      
      // Reset form
      setSelectedPartyId('');
      setLineItems([]);
      setInvoiceNumber(prev => {
        const parts = prev.split('-');
        const lastPart = parts[2];
        const newLastPart = (parseInt(lastPart) + 1).toString().padStart(3, '0');
        return `${parts[0]}-${parts[1]}-${newLastPart}`;
      });
      
      if (onSuccess) onSuccess();
      
      setError(null);
    } catch (err) {
      console.error('Error saving invoice:', err);
      setError('Failed to save invoice. Please try again.');
    } finally {
      setLoading(false);
    }
  };
  
  // Add new state for party creation
  const [openPartyDialog, setOpenPartyDialog] = useState(false);
  const [newParty, setNewParty] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    categoryDiscounts: {} as Record<string, number>,
    productDiscounts: {} as Record<string, number>
  });
  const [creatingParty, setCreatingParty] = useState(false);
  
  // Handle opening the party creation dialog
  const handleOpenPartyDialog = () => {
    setNewParty({
      name: '',
      email: '',
      phone: '',
      address: '',
      categoryDiscounts: {},
      productDiscounts: {}
    });
    setOpenPartyDialog(true);
  };
  
  // Handle party input changes
  const handlePartyInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewParty(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  // Handle creating a new party
  const handleCreateParty = async () => {
    if (!newParty.name) {
      setError('Party name is required');
      return;
    }
    
    try {
      setCreatingParty(true);
      
      // Add new party to Firestore
      const partyRef = await addDoc(collection(db, 'parties'), {
        ...newParty,
        createdAt: serverTimestamp()
      });
      
      // Add the new party to the local state
      const newPartyWithId = {
        ...newParty,
        id: partyRef.id
      };
      
      // Update parties list
      parties.push(newPartyWithId);
      
      // Select the newly created party
      setSelectedPartyId(partyRef.id);
      
      // Close the dialog
      setOpenPartyDialog(false);
      setError(null);
    } catch (err) {
      console.error('Error creating party:', err);
      setError('Failed to create party. Please try again.');
    } finally {
      setCreatingParty(false);
    }
  };
  
  return (

    <Layout>
    <Box sx={{ mt: 3 }}>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Invoice Details
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
          <TextField
            label="Invoice Number"
            value={invoiceNumber}
            onChange={(e) => setInvoiceNumber(e.target.value)}
            sx={{ width: '30%' }}
          />
          
          <TextField
            label="Date"
            type="date"
            value={invoiceDate}
            onChange={(e) => setInvoiceDate(e.target.value)}
            sx={{ width: '30%' }}
          />
          
          <Box sx={{ width: '40%', display: 'flex', gap: 1 }}>
            <FormControl sx={{ flexGrow: 1 }}>
              <InputLabel>Party</InputLabel>
              <Select
                value={selectedPartyId}
                label="Party"
                onChange={(e) => setSelectedPartyId(e.target.value)}
                disabled={loadingParties}
              >
                {parties.map(party => (
                  <MenuItem key={party.id} value={party.id}>
                    {party.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <Button 
              variant="outlined" 
              onClick={handleOpenPartyDialog}
              sx={{ mt: 1 }}
            >
              New Party
            </Button>
          </Box>
        </Box>
        
        <Typography variant="h6" gutterBottom>
          Products
        </Typography>
        
        <Box sx={{ display: 'flex', gap: 2, mb: 3, alignItems: 'center' }}>
          <FormControl sx={{ width: '70%' }}>
            <InputLabel>Add Product</InputLabel>
            <Select
              value={selectedProductId}
              label="Add Product"
              onChange={(e) => setSelectedProductId(e.target.value)}
              disabled={loadingProducts}
            >
              {products.map(product => (
                <MenuItem key={product.id} value={product.id}>
                  {product.name} - ₹{product.price}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          
          <Button 
            variant="contained" 
            startIcon={<AddIcon />}
            onClick={handleAddProduct}
            disabled={!selectedProductId}
          >
            Add
          </Button>
        </Box>
        
        <TableContainer component={Paper} variant="outlined">
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Product</TableCell>
                <TableCell align="right">Price</TableCell>
                <TableCell align="right">Quantity</TableCell>
                <TableCell align="right">Discount</TableCell>
                <TableCell align="right">Total</TableCell>
                <TableCell align="center">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {lineItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    No products added
                  </TableCell>
                </TableRow>
              ) : (
                lineItems.map((item, index) => (
                  <TableRow key={index}>
                    <TableCell>{item.name}</TableCell>
                    <TableCell align="right">₹{item.price}</TableCell>
                    <TableCell align="right">
                      <TextField
                        type="number"
                        size="small"
                        value={item.quantity}
                        onChange={(e) => handleUpdateQuantity(index, parseInt(e.target.value))}
                        inputProps={{ min: 1 }}
                        sx={{ width: '70px' }}
                      />
                    </TableCell>
                    <TableCell align="right">
                      {item.discount > 0 ? (
                        <>
                          {item.discount}% 
                          <Typography variant="caption" color="text.secondary" sx={{ ml: 1 }}>
                            ({item.discountType === 'product' ? 'Product' : 'Category'})
                          </Typography>
                        </>
                      ) : (
                        'None'
                      )}
                    </TableCell>
                    <TableCell align="right">₹{item.finalPrice}</TableCell>
                    <TableCell align="center">
                      <IconButton 
                        size="small" 
                        color="error"
                        onClick={() => handleRemoveItem(index)}
                      >
                        <DeleteIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))
              )}
              
              {/* Summary rows */}
              <TableRow>
                <TableCell colSpan={4} align="right">
                  <Typography variant="subtitle2">Subtotal:</Typography>
                </TableCell>
                <TableCell align="right">₹{subtotal.toFixed(2)}</TableCell>
                <TableCell />
              </TableRow>
              
              <TableRow>
                <TableCell colSpan={4} align="right">
                  <Typography variant="subtitle2">Discount:</Typography>
                </TableCell>
                <TableCell align="right">₹{discountAmount.toFixed(2)}</TableCell>
                <TableCell />
              </TableRow>
              
              <TableRow>
                <TableCell colSpan={4} align="right">
                  <Typography variant="subtitle1" fontWeight="bold">Total:</Typography>
                </TableCell>
                <TableCell align="right">
                  <Typography variant="subtitle1" fontWeight="bold">
                    ₹{total.toFixed(2)}
                  </Typography>
                </TableCell>
                <TableCell />
              </TableRow>
            </TableBody>
          </Table>
        </TableContainer>
        
        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleSaveInvoice}
            disabled={loading || lineItems.length === 0 || !selectedPartyId}
          >
            {loading ? <CircularProgress size={24} /> : 'Save Invoice'}
          </Button>
        </Box>
      </Paper>
      
      {/* Party Creation Dialog */}
      <Dialog open={openPartyDialog} onClose={() => setOpenPartyDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Create New Party</DialogTitle>
        <DialogContent>
          <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              label="Party Name"
              name="name"
              value={newParty.name}
              onChange={handlePartyInputChange}
              fullWidth
              required
            />
            
            <TextField
              label="Email"
              name="email"
              type="email"
              value={newParty.email}
              onChange={handlePartyInputChange}
              fullWidth
            />
            
            <TextField
              label="Phone"
              name="phone"
              value={newParty.phone}
              onChange={handlePartyInputChange}
              fullWidth
            />
            
            <TextField
              label="Address"
              name="address"
              value={newParty.address}
              onChange={handlePartyInputChange}
              fullWidth
              multiline
              rows={3}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenPartyDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleCreateParty} 
            variant="contained"
            disabled={!newParty.name || creatingParty}
          >
            {creatingParty ? <CircularProgress size={24} /> : 'Create Party'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>

    </Layout>
  );
}