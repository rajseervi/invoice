"use client";
import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Paper,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  InputAdornment,
  Grid,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import { 
  Save as SaveIcon,
  ArrowBack as ArrowBackIcon 
} from '@mui/icons-material';
import { collection, getDocs, addDoc } from 'firebase/firestore';
import { db } from '@/firebase/config';
import Layout from '@/app/components/Layout/Layout';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function NewProductPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<any[]>([]);
  const [loadingCategories, setLoadingCategories] = useState(true);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  
  // Product form state
  const [product, setProduct] = useState({
    name: '',
    description: '',
    price: '',
    category: '',
    sku: '',
    stock: '',
    unit: 'piece',
    hsnCode: '',
    taxRate: '',
  });

  // Form validation
  const [errors, setErrors] = useState({
    name: false,
    price: false,
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    try {
      setLoadingCategories(true);
      const categoriesCollection = collection(db, 'categories');
      const categoriesSnapshot = await getDocs(categoriesCollection);
      const categoriesList = categoriesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setCategories(categoriesList);
    } catch (error) {
      console.error('Error fetching categories:', error);
      showSnackbar('Failed to load categories', 'error');
    } finally {
      setLoadingCategories(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    setProduct({
      ...product,
      [name as string]: value
    });

    // Clear error when field is edited
    if (errors[name as keyof typeof errors]) {
      setErrors({
        ...errors,
        [name as string]: false
      });
    }
  };

  const validateForm = () => {
    const newErrors = {
      name: !product.name.trim(),
      price: !product.price || isNaN(Number(product.price)) || Number(product.price) <= 0,
    };
    
    setErrors(newErrors);
    return !Object.values(newErrors).some(error => error);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      showSnackbar('Please correct the errors in the form', 'error');
      return;
    }

    try {
      setLoading(true);
      
      // Prepare product data
      const productData = {
        ...product,
        price: Number(product.price),
        stock: product.stock ? Number(product.stock) : 0,
        taxRate: product.taxRate ? Number(product.taxRate) : 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      // Add product to Firestore
      await addDoc(collection(db, 'products'), productData);
      
      showSnackbar('Product created successfully', 'success');
      
      // Redirect to products list after short delay
      setTimeout(() => {
        router.push('/products');
      }, 1500);
      
    } catch (error) {
      console.error('Error creating product:', error);
      showSnackbar('Failed to create product', 'error');
      setLoading(false);
    }
  };

  const showSnackbar = (message: string, severity: 'success' | 'error') => {
    setSnackbar({ open: true, message, severity });
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  return (
    <Layout>
      <Box sx={{ p: { xs: 2, md: 3 } }}>
        <Box sx={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center',
          mb: 3
        }}>
          <Typography variant="h4" component="h1">
            Add New Product
          </Typography>
          <Button 
            component={Link}
            href="/products"
            startIcon={<ArrowBackIcon />}
            variant="outlined"
          >
            Back to Products
          </Button>
        </Box>

        <Paper 
          component="form" 
          onSubmit={handleSubmit}
          elevation={2} 
          sx={{ p: 3, borderRadius: 2 }}
        >
          <Grid container spacing={3}>
            {/* Product Name */}
            <Grid item xs={12} md={6}>
              <TextField
                name="name"
                label="Product Name"
                value={product.name}
                onChange={handleChange}
                fullWidth
                required
                error={errors.name}
                helperText={errors.name ? "Product name is required" : ""}
              />
            </Grid>
            
            {/* SKU */}
            <Grid item xs={12} md={6}>
              <TextField
                name="sku"
                label="SKU (Optional)"
                value={product.sku}
                onChange={handleChange}
                fullWidth
              />
            </Grid>
            
            {/* Description */}
            <Grid item xs={12}>
              <TextField
                name="description"
                label="Description (Optional)"
                value={product.description}
                onChange={handleChange}
                fullWidth
                multiline
                rows={3}
              />
            </Grid>
            
            {/* Price */}
            <Grid item xs={12} md={4}>
              <TextField
                name="price"
                label="Price"
                value={product.price}
                onChange={handleChange}
                fullWidth
                required
                type="number"
                InputProps={{
                  startAdornment: <InputAdornment position="start">₹</InputAdornment>,
                }}
                error={errors.price}
                helperText={errors.price ? "Valid price is required" : ""}
              />
            </Grid>
            
            {/* Stock */}
            <Grid item xs={12} md={4}>
              <TextField
                name="stock"
                label="Stock Quantity (Optional)"
                value={product.stock}
                onChange={handleChange}
                fullWidth
                type="number"
              />
            </Grid>
            
            {/* Unit */}
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Unit</InputLabel>
                <Select
                  name="unit"
                  value={product.unit}
                  label="Unit"
                  onChange={handleChange}
                >
                  <MenuItem value="piece">Piece</MenuItem>
                  <MenuItem value="kg">Kilogram (kg)</MenuItem>
                  <MenuItem value="g">Gram (g)</MenuItem>
                  <MenuItem value="l">Liter (l)</MenuItem>
                  <MenuItem value="ml">Milliliter (ml)</MenuItem>
                  <MenuItem value="m">Meter (m)</MenuItem>
                  <MenuItem value="cm">Centimeter (cm)</MenuItem>
                  <MenuItem value="box">Box</MenuItem>
                  <MenuItem value="pack">Pack</MenuItem>
                  <MenuItem value="set">Set</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            {/* Category */}
            <Grid item xs={12} md={4}>
              <FormControl fullWidth>
                <InputLabel>Category (Optional)</InputLabel>
                <Select
                  name="category"
                  value={product.category}
                  label="Category (Optional)"
                  onChange={handleChange}
                  disabled={loadingCategories}
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {categories.map((category) => (
                    <MenuItem key={category.id} value={category.id}>
                      {category.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
            
            {/* HSN Code */}
            <Grid item xs={12} md={4}>
              <TextField
                name="hsnCode"
                label="HSN Code (Optional)"
                value={product.hsnCode}
                onChange={handleChange}
                fullWidth
              />
            </Grid>
            
            {/* Tax Rate */}
            <Grid item xs={12} md={4}>
              <TextField
                name="taxRate"
                label="Tax Rate % (Optional)"
                value={product.taxRate}
                onChange={handleChange}
                fullWidth
                type="number"
                InputProps={{
                  endAdornment: <InputAdornment position="end">%</InputAdornment>,
                }}
              />
            </Grid>
            
            {/* Submit Button */}
            <Grid item xs={12} sx={{ mt: 2 }}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                size="large"
                startIcon={<SaveIcon />}
                disabled={loading}
                sx={{ minWidth: 150 }}
              >
                {loading ? <CircularProgress size={24} /> : "Save Product"}
              </Button>
            </Grid>
          </Grid>
        </Paper>
      </Box>
      
      {/* Snackbar for notifications */}
      <Snackbar 
        open={snackbar.open} 
        autoHideDuration={6000} 
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          onClose={handleCloseSnackbar} 
          severity={snackbar.severity as any} 
          sx={{ width: '100%' }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Layout>
  );
}