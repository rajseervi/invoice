'use client';

import React, { useState, useEffect, Suspense } from 'react';
import { useParams, useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import {
  Box,
  Typography,
  Paper,
  Skeleton,
  Alert,
} from '@mui/material';
import { doc, getDoc, updateDoc, serverTimestamp, collection } from 'firebase/firestore';
import { db } from '@/firebase/config';
import Layout from '@/app/components/Layout/Layout';

// Dynamically import ProductForm with loading fallback
const ProductForm = dynamic(() => import('@/components/ProductForm'), {
  loading: () => <Skeleton variant="rectangular" height={400} />,
  ssr: false
});

export default function EditProductPage() {
  const params = useParams();
  const router = useRouter();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        if (!params.id) {
          throw new Error('Product ID is required');
        }

        const firestoreDb = await db();
        const productDoc = await getDoc(doc(firestoreDb, 'products', params.id as string));
        
        if (!productDoc.exists()) {
          throw new Error('Product not found');
        }

        setProduct({
          id: productDoc.id,
          ...productDoc.data()
        });
      } catch (err) {
        console.error('Error fetching product:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch product');
      } finally {
        setLoading(false);
      }
    };

    fetchProduct();
  }, [params.id]);

  const handleSuccess = () => {
    router.push('/products');
  };

  const handleSubmit = async (data: any) => {
    try {
      const firestoreDb = await db();
      const productRef = doc(firestoreDb, 'products', params.id as string);
      
      await updateDoc(productRef, {
        ...data,
        updatedAt: serverTimestamp()
      });
      handleSuccess();
    } catch (err) {
      console.error('Error updating product:', err);
      setError(err instanceof Error ? err.message : 'Failed to update product');
    }
  };

  if (loading) {
    return (
      <Layout>
        <Box sx={{ p: 3 }}>
          <Skeleton variant="text" width={200} height={40} sx={{ mb: 3 }} />
          <Paper sx={{ p: 3 }}>
            <Skeleton variant="rectangular" height={400} />
          </Paper>
        </Box>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      </Layout>
    );
  }

  return (
    <Layout>
      <Box sx={{ p: 3 }}>
        <Typography variant="h5" sx={{ mb: 3 }}>
          Edit Product
        </Typography>
        <Paper sx={{ p: 3 }}>
          {product && (
            <ProductForm
              initialData={product}
              onSubmit={handleSubmit}
              onCancel={() => router.push('/products')}
              mode="edit"
            />
          )}
        </Paper>
      </Box>
    </Layout>
  );
}