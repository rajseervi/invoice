"use client"
import React from 'react';
import { useRouter } from 'next/navigation';
import Layout from "../../app/components/Layout/Layout";
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  Button,
  Card,
  CardContent,
  CardActions
} from '@mui/material';
import {
  Inventory as InventoryIcon,
  Category as CategoryIcon
} from '@mui/icons-material';

export default function InventoryPage() {
  const router = useRouter();

  return (
    <Layout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" gutterBottom>
          Inventory Management
        </Typography>
        
        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <InventoryIcon fontSize="large" color="primary" sx={{ mr: 2 }} />
                  <Typography variant="h5">Products</Typography>
                </Box>
                <Typography variant="body1" color="text.secondary">
                  Manage your product inventory, update stock levels, and add new products.
                </Typography>
              </CardContent>
              <CardActions>
                <Button 
                  size="large" 
                  onClick={() => router.push('/inventory/products')}
                >
                  View Products
                </Button>
              </CardActions>
            </Card>
          </Grid>
          
          <Grid item xs={12} md={6}>
            <Card>
              <CardContent>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  <CategoryIcon fontSize="large" color="secondary" sx={{ mr: 2 }} />
                  <Typography variant="h5">Categories</Typography>
                </Box>
                <Typography variant="body1" color="text.secondary">
                  Organize your products with categories for better inventory management.
                </Typography>
              </CardContent>
              <CardActions>
                <Button 
                  size="large" 
                  onClick={() => router.push('/inventory/categories')}
                >
                  View Categories
                </Button>
              </CardActions>
            </Card>
          </Grid>
        </Grid>
      </Container>
    </Layout>
  );
}