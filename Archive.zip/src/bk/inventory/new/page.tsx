'use client';
import React from 'react';
import { Container, Typography } from '@mui/material';
import { useRouter } from 'next/navigation';  // Make sure this import exists
import DashboardLayout from '../../../components/DashboardLayout';
import InventoryForm from '@/components/Inventory/InventoryForm';
import { InventoryFormData } from '@/types/inventory';

export default function NewInventoryItem() {
  const router = useRouter();  // Initialize router at the top of the component

  const handleSubmit = async (data: InventoryFormData) => {
    try {
      // TODO: Add API call to create inventory item
      console.log('Creating inventory item:', data);
      router.push('/inventory');
    } catch (error) {
      console.error('Error creating inventory item:', error);
    }
  };

  return (
    <DashboardLayout>
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Typography variant="h4" sx={{ mb: 4 }}>Add New Item</Typography>
        <InventoryForm
          onSubmit={handleSubmit}
          onCancel={() => router.push('/inventory')}
        />
      </Container>
    </DashboardLayout>
  );
}